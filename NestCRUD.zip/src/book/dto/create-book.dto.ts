export class CreateBookDto {
    bookName:string;
    authorName:string;
   
}
