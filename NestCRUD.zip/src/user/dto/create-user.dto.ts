export class CreateUserDto {
    firstName:string;
    lastName:string;
    age:number;
}
